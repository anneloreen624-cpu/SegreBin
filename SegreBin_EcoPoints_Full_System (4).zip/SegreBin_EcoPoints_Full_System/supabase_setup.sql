-- SegreBin EcoPoints schema for Supabase
-- Run this whole file in Supabase Dashboard > SQL Editor as the project owner.
-- Use only a school-approved pilot. Student IDs must be added by an administrator.

create extension if not exists pgcrypto with schema extensions;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table if not exists public.allowed_student_ids (
  student_id text primary key check (length(student_id) between 1 and 40),
  invite_hash text not null,
  claimed_by uuid unique references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.student_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  student_id text not null unique references public.allowed_student_ids(student_id),
  display_name text not null check (length(display_name) between 1 and 40),
  points integer not null default 0 check (points >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.sort_events (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  category text not null check (category in ('paper','plastic')),
  points_delta integer not null default 10,
  created_at timestamptz not null default now()
);

create table if not exists public.points_audit (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  points_delta integer not null,
  reason text not null,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create index if not exists sort_events_user_time_idx on public.sort_events(user_id, created_at desc);
create index if not exists student_profiles_points_idx on public.student_profiles(points desc);

alter table public.allowed_student_ids enable row level security;
alter table public.student_profiles enable row level security;
alter table public.admin_users enable row level security;
alter table public.sort_events enable row level security;
alter table public.points_audit enable row level security;

revoke all on public.allowed_student_ids, public.student_profiles, public.admin_users, public.sort_events, public.points_audit from anon, authenticated;
grant select on public.student_profiles to authenticated;
grant select on public.sort_events, public.points_audit to authenticated;

drop policy if exists "student reads own profile" on public.student_profiles;
create policy "student reads own profile" on public.student_profiles for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "student reads own sort events" on public.sort_events;
create policy "student reads own sort events" on public.sort_events for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "student reads own audit" on public.points_audit;
create policy "student reads own audit" on public.points_audit for select to authenticated using (user_id = (select auth.uid()));

create or replace function private.has_admin_role()
returns boolean language sql stable security definer set search_path = ''
as $$ select exists (select 1 from public.admin_users a where a.user_id = (select auth.uid())) $$;
revoke all on function private.has_admin_role() from public, anon, authenticated;

create or replace function public.is_current_user_admin()
returns boolean language sql stable security definer set search_path = ''
as $$ select private.has_admin_role() $$;
revoke all on function public.is_current_user_admin() from public, anon;
grant execute on function public.is_current_user_admin() to authenticated;

create or replace function public.register_student(p_student_id text, p_display_name text, p_invite_code text)
returns void language plpgsql security definer set search_path = ''
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'Sign in first.'; end if;
  if length(trim(coalesce(p_student_id,''))) not between 1 and 40 then raise exception 'Invalid student ID.'; end if;
  if length(trim(coalesce(p_display_name,''))) not between 1 and 40 then raise exception 'Display name must be 1–40 characters.'; end if;
  if length(coalesce(p_invite_code,'')) < 8 then raise exception 'Invalid invite code.'; end if;
  if exists (select 1 from public.student_profiles where user_id=v_user) then raise exception 'This account is already registered.'; end if;
  update public.allowed_student_ids
    set claimed_by = v_user
    where student_id = trim(p_student_id)
      and claimed_by is null
      and invite_hash = encode(extensions.digest(p_invite_code, 'sha256'), 'hex');
  if not found then raise exception 'Student ID or invite code is invalid, or the invitation was already used. Ask your teacher.'; end if;
  insert into public.student_profiles(user_id, student_id, display_name)
  values (v_user, trim(p_student_id), trim(p_display_name));
end;
$$;
revoke all on function public.register_student(text,text,text) from public, anon;
grant execute on function public.register_student(text,text,text) to authenticated;

create or replace function public.get_my_profile()
returns table(student_id text, display_name text, points integer, created_at timestamptz)
language sql stable security invoker set search_path = ''
as $$ select p.student_id, p.display_name, p.points, p.created_at from public.student_profiles p where p.user_id=(select auth.uid()) $$;
revoke all on function public.get_my_profile() from public, anon;
grant execute on function public.get_my_profile() to authenticated;

create or replace function public.record_sort(p_category text)
returns jsonb language plpgsql security definer set search_path = ''
as $$
declare v_user uuid := auth.uid(); v_last timestamptz; v_points integer;
begin
  if v_user is null then raise exception 'Sign in to earn points.'; end if;
  if p_category not in ('paper','plastic') then raise exception 'Choose paper or plastic.'; end if;
  if not exists (select 1 from public.student_profiles p where p.user_id=v_user) then raise exception 'Student registration is required.'; end if;
  select max(s.created_at) into v_last from public.sort_events s where s.user_id=v_user;
  if v_last is not null and v_last > now() - interval '20 seconds' then
    raise exception 'Please wait 20 seconds between point-earning scans.';
  end if;
  insert into public.sort_events(user_id,category,points_delta) values (v_user,p_category,10);
  update public.student_profiles set points=points+10 where user_id=v_user returning points into v_points;
  return jsonb_build_object('points_awarded',10,'total_points',v_points);
end;
$$;
revoke all on function public.record_sort(text) from public, anon;
grant execute on function public.record_sort(text) to authenticated;

create or replace function public.get_my_recent_activity()
returns table(category text, points_delta integer, created_at timestamptz)
language sql stable security invoker set search_path = ''
as $$ select s.category,s.points_delta,s.created_at from public.sort_events s where s.user_id=(select auth.uid()) order by s.created_at desc limit 10 $$;
revoke all on function public.get_my_recent_activity() from public, anon;
grant execute on function public.get_my_recent_activity() to authenticated;

create or replace function public.get_leaderboard()
returns table(display_name text, points integer)
language sql stable security definer set search_path = ''
as $$ select p.display_name,p.points from public.student_profiles p order by p.points desc, p.display_name asc limit 100 $$;
revoke all on function public.get_leaderboard() from public, anon;
grant execute on function public.get_leaderboard() to authenticated;

create or replace function public.admin_add_student_invite(p_student_id text, p_invite_code text)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if not private.has_admin_role() then raise exception 'Administrator access required.'; end if;
  if length(trim(coalesce(p_student_id,''))) not between 1 and 40 then raise exception 'Student ID must be 1–40 characters.'; end if;
  if length(coalesce(p_invite_code,'')) < 8 then raise exception 'Invite code must be at least 8 characters.'; end if;
  insert into public.allowed_student_ids(student_id,invite_hash)
  values(trim(p_student_id),encode(extensions.digest(p_invite_code,'sha256'),'hex'));
exception when unique_violation then raise exception 'That student ID already has an invitation or account.';
end;
$$;
revoke all on function public.admin_add_student_invite(text,text) from public, anon;
grant execute on function public.admin_add_student_invite(text,text) to authenticated;

create or replace function public.admin_list_students()
returns table(student_id text, display_name text, points integer, created_at timestamptz)
language plpgsql security definer set search_path = ''
as $$
begin
  if not private.has_admin_role() then raise exception 'Administrator access required.'; end if;
  return query select p.student_id,p.display_name,p.points,p.created_at from public.student_profiles p order by p.created_at desc;
end;
$$;
revoke all on function public.admin_list_students() from public, anon;
grant execute on function public.admin_list_students() to authenticated;

create or replace function public.admin_adjust_points(p_student_id text, p_delta integer, p_reason text)
returns integer language plpgsql security definer set search_path = ''
as $$
declare v_user uuid; v_points integer;
begin
  if not private.has_admin_role() then raise exception 'Administrator access required.'; end if;
  if p_delta=0 or abs(p_delta)>100 then raise exception 'Adjustment must be between -100 and 100, not zero.'; end if;
  if length(trim(coalesce(p_reason,''))) not between 1 and 160 then raise exception 'Provide a short reason for the audit log.'; end if;
  select p.user_id into v_user from public.student_profiles p where p.student_id=trim(p_student_id);
  if v_user is null then raise exception 'Student ID not found.'; end if;
  update public.student_profiles set points=greatest(0,points+p_delta) where user_id=v_user returning points into v_points;
  insert into public.points_audit(user_id,points_delta,reason,actor_id) values(v_user,p_delta,trim(p_reason),auth.uid());
  return v_points;
end;
$$;
revoke all on function public.admin_adjust_points(text,integer,text) from public, anon;
grant execute on function public.admin_adjust_points(text,integer,text) to authenticated;

-- ADMIN BOOTSTRAP:
-- 1) Create/sign up your own account in the website.
-- 2) In Supabase Dashboard > Authentication > Users, copy your user's UUID.
-- 3) Replace YOUR_AUTH_USER_UUID below with that UUID and run this single insert.
-- Keep the admin account private and enable MFA if available.
-- insert into public.admin_users(user_id) values ('YOUR_AUTH_USER_UUID');
