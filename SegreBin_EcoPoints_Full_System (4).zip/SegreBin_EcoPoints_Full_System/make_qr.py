#!/usr/bin/env python3
"""Generate a QR code for a deployed SegreBin EcoPoints website URL."""
import sys
from urllib.parse import urlparse
import qrcode

if len(sys.argv) != 2:
    raise SystemExit("Usage: python make_qr.py https://your-published-site.example")
url = sys.argv[1].strip()
parsed = urlparse(url)
if parsed.scheme != "https" or not parsed.netloc:
    raise SystemExit("Please provide the final public HTTPS website URL.")
qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=12, border=4)
qr.add_data(url)
qr.make(fit=True)
img = qr.make_image(fill_color="#111111", back_color="white")
img.save("segrebin_ecopoints_qr.png")
print("Created segrebin_ecopoints_qr.png for:", url)
