# SegreBin EcoPoints — full research-project starter

This bundle contains a responsive website, Supabase database schema, and deployment instructions. It is a deployable starter, not yet a live public website. A real QR code must be generated from the final public URL after hosting.

## What is included
- Student email/password sign-in
- Student ID registration restricted by a one-time invitation created by an administrator
- Persistent points in a shared PostgreSQL database
- Paper/plastic sorting actions (+10 points, with a 20-second rate limit)
- Public-to-signed-in leaderboard showing display names and points only
- Admin invitation creation, student list, and audited point corrections
- Row Level Security and database-side permission checks
- QR code instructions and a generator script

## Important limitations
- The site records a student's selected action; it cannot prove the item was physically sorted correctly. A teacher should supervise the pilot. The 20-second cooldown reduces accidental spam but is not anti-cheat proof.
- Use school-approved accounts and get teacher/parent approval before collecting student data. Do not collect full names, birth dates, home addresses, phone numbers, or other unnecessary personal data.
- The site uses Supabase's browser client from a CDN, so the deployed site needs an internet connection.
- This is a student research prototype. Have a qualified adult review security and school privacy requirements before real-world use.

## Deployment overview (free tiers may have limits/change)
1. An adult project owner creates a Supabase project at https://supabase.com/.
2. Open Supabase Dashboard → SQL Editor → New query. Paste and run all of `supabase_setup.sql`.
3. Host the `index.html` file on a static web host such as GitHub Pages, Cloudflare Pages, or Netlify. Upload this file as the site's `index.html`. Keep it in a private repository until the teacher approves it, then publish according to school policy.
4. Open the deployed URL. Click **Settings** and paste the Supabase Project URL and the project's **publishable key** (or legacy anon key). Never use a service-role/secret key in the browser.
5. Have a teacher/adult create the first administrator account using Supabase Dashboard → Authentication → Users (or create it through the website's sign-up form). Copy that account's Auth user UUID. In the SQL Editor, run the one-time bootstrap INSERT at the bottom of `supabase_setup.sql`, replacing `YOUR_AUTH_USER_UUID` with the copied UUID. Keep this admin account private. If email confirmation is enabled, confirm the email before signing in. The administrator does not need a student invitation.
6. Reload the site and sign in as the administrator. Use **Admin** to create one-time invitations for each student ID. Give each code privately to the matching student; it can only be claimed once. Students create accounts with a school-approved email and password, their ID, and invitation code.
7. Test using two separate student accounts: each should see their own profile/history, the same leaderboard, and persistent points after sign-out/sign-in. Test that a student cannot access admin functions.
8. Only after the final URL works on a phone, generate a QR code using `make_qr.py` (instructions below). Print that QR code and test it with a second phone before displaying it.

## QR code (after publishing only)
Install Python package `qrcode[pil]` on a computer where Python is available:
`python -m pip install "qrcode[pil]"`
Then run:
`python make_qr.py https://YOUR-PUBLISHED-SITE-URL`
It creates `segrebin_ecopoints_qr.png`. The QR code opens the website; students still need to sign in. For separate bins, you may create separate QR codes with query labels only after the basic deployment works.

## Privacy and security notes
- The public browser only uses the Supabase project URL and publishable/anon key. The database SQL enables RLS, restricts direct table grants, and uses RPCs for actions.
- Never place Supabase `service_role`, secret keys, database passwords, or administrator passwords in HTML, JavaScript, QR codes, or a public repository.
- Admin creation is intentionally a manual one-time step in Supabase. Protect that account and do not share its credentials.
- Student IDs and invite codes should be distributed privately. Display names can be nicknames. The leaderboard never shows student IDs or emails.
- If a student loses access, the teacher/admin should help through the Supabase dashboard; don't share passwords.
- Review Supabase RLS/function permissions if changing this code. Official docs: https://supabase.com/docs/guides/database/row-level-security and https://supabase.com/docs/guides/database/functions

## Files
- `index.html` — website
- `supabase_setup.sql` — tables, RLS policies, and secure database functions
- `make_qr.py` — creates a QR code for a published URL
- `README.md` — this guide
